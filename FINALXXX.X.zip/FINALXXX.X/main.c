#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
//#include <htc.h>
#define _XTAL_FREQ 8000000
// using namespace std;


char str[20];
short btnPressed = 0;

void buttonSet(void){
    TRISBbits.RB0 = 1;
    RCONbits.IPEN = 1;
    INTCONbits.GIE = 1;
    INTCONbits.INT0IE = 1;
    INTCONbits.INT0IF = 0;
}

void setDuty(float percentage){
    CCPR1L = (int)((float)PR2 * percentage);
    CCP1CONbits.DC1B = 0;//;
    CCPR2L = (int)((float)PR2 * percentage);
    CCP2CONbits.DC2B = 0;//;
}

void delay_mill(unsigned int t){
    T1CON = 0b10110100;// 8 prescaler
    PIR1bits.TMR1IF = 0;
    TMR1 = 0xFF - t * 125;
    T1CONbits.TMR1ON = 1;
    while(PIR1bits.TMR1IF == 0);
    PIR1bits.TMR1IF = 0;
    T1CON = 0b00110100;
}

void delay_micro(unsigned int ammount){
    T1CON = 0b10000100;// 1 prescaler
    PIR1bits.TMR1IF = 0;
    TMR1 = 0xFF - (ammount);
    T1CONbits.TMR1ON = 1;
    while(PIR1bits.TMR1IF == 0);
    PIR1bits.TMR1IF = 0;
    T1CON = 0b10000100;
    
}
void breathing(void){
    CCP1CON = 0b00001100;// set pwm mode
    T2CON = 0b00000101;// set timer two prescale to 4
    TRISCbits.RC2 = 0;// set RC2 as output (a.k.a. ccp1)
    ADCON0 = 0x01;
    ADCON1 = 0b00001110;
    ADCON2 = 0b10001100;
    PR2 = 249;
    
    // period = (PR2+1)*4*Tosc*(TMR2 prescaler) = (249 + 1) * 4 * 0.25�s * 4 = 0.01s ~= 1ms
    int i = 0;
    
    while(getMode() == 1){
        ADCON0bits.GO = 1;
        while(ADCON0bits.GO == 1);
        int del = (int)(((((float)ADRES)/1024)*1.5  + 0.5)*10);
        for( i = 0; i < 50; i++){
            setDuty(((float)i)/50);
            delay_mill(del);
        }
        for( i = 50; i > 0; i--){
            setDuty(((float)i)/50);
            delay_mill(del);
        }
    }
    TRISCbits.RC2 = 1;
    CCP1CON = 0b00000000;
}

char sevenSegment (int value){
    
    char res ;
    switch(value){
        
        case 0:
            res = 0b0111111;
            break;
        case 1:
            res = 0b0001010;
            break;
        case 2:
            res = 0b1011101;
            break;
        case 3:
            res = 0b1011011;
            break;
        case 4:
            res = 0b1101010;
            break;
        case 5:
            res = 0b1110011;
            break;
        case 6:
            res = 0b1110111;
            break;
        case 7:
            res = 0b0011010;
            break;
        case 8:
            res = 0b1111111;
            break;
         case 9:
             res =0b1111010;
            break;
            
        default:
            break;
    }
return res; 
                 
            
    
}
void countdown(void){
    
    CCP2CON = 0b00001100;// set pwm mode
    T2CON = 0b00000110;// set timer two prescale to 16
    TRISCbits.RC1 = 0;// set RC1 as output (a.k.a. ccp2)
    CCPR2L = 0;
    CCP2CONbits.DC2B = 0;//;
    int i = 0;
    PR2 = 249;
    buttonSet();
    
    // period = (PR2+1)*4*Tosc*(TMR2 prescaler) = (249 + 1) * 4 * 0.25�s * 16 = 0.04s ~= 4ms
    
    while(getMode() == 2){
        while(btnPressed == 0 && getMode() == 2);
        if(btnPressed == 0){
            TRISCbits.RC1 = 1;
            CCP2CON = 0b00000000;
            return;
        }
        btnPressed = 0;
        for(i = 0; i<= getRotationSteps(); i++){
            setDuty(0.1 + (0.5 * (((float)i)/(float) (getRotationSteps()))));
            delay_mill(500);
            delay_mill(500);
        }
    }
    TRISCbits.RC1 = 1;
    CCP2CON = 0b00000000;
}

void motor(void){
    CCP2CON = 0b00001100;// set pwm mode
    T2CON = 0b00000110;// set timer two prescale to 16
    TRISCbits.RC1 = 0;// set RC1 as output (a.k.a. ccp2)
    CCPR2L = 0;
    CCP2CONbits.DC2B = 0;//;
    int i = 0;
    PR2 = 249;
    ADCON0 = 0x01;
    ADCON1 = 0b00001110;
    ADCON2 = 0b10001100;
    
    while(getMode() == 1){
        ADCON0bits.GO = 1;
        while(ADCON0bits.GO == 1);
        float rotation = (((float)ADRES)/1024)*0.45 + 0.1;
        setDuty(rotation);
        int deg = (int)((((float)ADRES)/-1023)*180 + 90);
        sprintf(str,"%d\n", deg);
        UART_Write_Text(str);
    }
}
void degree(int val){
    CCP2CON = 0b00001100;// set pwm mode
    T2CON = 0b00000110;// set timer two prescale to 16
    TRISCbits.RC1 = 0;// set RC1 as output (a.k.a. ccp2)
    CCPR2L = 0;
    CCP2CONbits.DC2B = 0;//;
    int i = 0;
    PR2 = 249;
    ADCON0 = 0x01;
    ADCON1 = 0b00001110;
    ADCON2 = 0b10001100;
    
    float rotation = (((float)(val + 90) )/180)*0.45 + 0.1;
    setDuty(rotation);
    
    
}

void Mode1(){
    ClearBuffer();
    UART_Write_Text("Enter Mode 1"); // TODO
    return ;
}
void Mode2()
{
    ClearBuffer();
    UART_Write_Text("Enter mode2");
    strcpy(str, GetString());
    float n = 0;
    while (1)
    {
        strcpy(str, GetString());
        if (str[0] == 'e')
        {
            ClearBuffer();
            break;
        }
        n = ADC_Read(7);
        n = n / 1023 * 5;
        char f2[10];
        sprintf(f2, " %.2f", n);
        UART_Write_Text(f2);
        __delay_ms(100);
    }
    return;
}
void main(void) 
{
    SYSTEM_Initialize();
//    char voltString[20] = "";
//    float potResult = 0;
//    int val = 0;
//    
//    int Period;
//    PWM_Init();                 /* Initialize PWM */
//    Period = setPeriodTo(50);   /* 50Hz PWM frequency */
    /* Note that period step size will gradually increase with PWM frequency */
//    int var = 0;
    
    //CONFIIGURE a/d
    //ADCON1bits.PCFG3 = 1;
    //ADCON1bits.PCFG2 = 1;
    //ADCON1bits.PCFG1 = 1;
    //ADCON1bits.PCFG0 = 1;
    
//    OSCCONbits.IRCF = 0x01;// 125KHZ
    
    //Input RB0
    //TRISA = 0;
    //TRISAbits.RA0 = 1;
    //TRISAbits.RA1 = 1;
    TRISB=0;
    TRISD = 0;
    char temperature_info[30] = {0};
    char light_info[30] = {0};
    
    

  
//        // Timer2 -> On, prescaler -> 4
//    T2CONbits.TMR2ON = 0b1;
//    T2CONbits.T2CKPS = 0b01;

//    // Internal Oscillator Frequency, Fosc = 125 kHz, Tosc = 8 �s
//    OSCCONbits.IRCF = 0b001;
//    
//    // PWM mode, P1A, P1C active-high; P1B, P1D active-high
//    CCP1CONbits.CCP1M = 0b1100;
//    
    // CCP1/RC2 -> Output
    
    // Set up PR2, CCP to decide PWM period and Duty Cycle
    /** 
     * PWM period
     * = (PR2 + 1) * 4 * Tosc * (TMR2 prescaler)
     * = (0x9b + 1) * 4 * 8�s * 4
     * = 0.019968s ~= 20ms
     */
//      PR2 = 155;
    int adder =0;
    float voltage = 0;
    float temperature = 0;
    float Vout;
    float Rldr;
    float lux;
    while(1){
        //adder = (int) ((((float) ADC_Read(0))/1023) * 99) ;
        
        
//        adder ++;
        adder = ADC_Read(1);
        Vout = (adder * 5.0/1024.0);
        sprintf(light_info, "light voltage: %f ", Vout);
        ClearBuffer();
        UART_Write_Text(light_info);
        
        
        adder = ADC_Read(0);
        voltage = (adder/1023.0) * 5;
        temperature = (voltage - 0.05) * 100;
        sprintf(temperature_info, "temp: %.2fC\n\r", temperature);
        ClearBuffer();
        UART_Write_Text(temperature_info);
        
        adder = (int) temperature;
        LATD = sevenSegment(adder%10);
        LATB = sevenSegment(adder/10);
        
        
//        if(getMode() == 2){
//            strcpy(str, GetString());
//            if(strlen(str) > 5){
//                val = atoi(str);
//                degree(val);
//                
//                ClearBuffer();
//            }
//        }
//        if(getMode() == 1)
////    motor();
    }
    return;

}




void __interrupt(high_priority) Hi_ISR(void)
{
    if(PIR1bits.CCP1IF == 1) {
        RC2 ^= 1;
        PIR1bits.CCP1IF = 0;
        TMR3 = 0;
    }
    
    if(INTCONbits.INT0IF == 1){
        INTCONbits.INT0IF = 0;
//        UART_Write_Text("Pushed Button\n");
//        UART_Write(0x0d);
        btnPressed = 1;
    }
    
    return ;
}