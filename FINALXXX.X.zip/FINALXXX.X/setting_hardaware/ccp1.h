#ifndef _CCP1_H
#define	_CCP1_H

#include <xc.h> // include processor files - each processor file is guarded.  

void CCP1_Initialize();
#endif	

