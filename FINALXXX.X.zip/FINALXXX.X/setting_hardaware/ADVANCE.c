#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
//#include <htc.h>
#define _XTAL_FREQ 8000000
// using namespace std;

char str[20];
void Mode1(){
    ClearBuffer();
    UART_Write_Text("Enter Mode 1"); // TODO
    return ;
}
void Mode2()
{
    ClearBuffer();
    UART_Write_Text("Enter mode2");
    strcpy(str, GetString());
    float n = 0;
    while (1)
    {
        strcpy(str, GetString());
        if (str[0] == 'e')
        {
            ClearBuffer();
            break;
        }
        n = ADC_Read(7);
        n = n / 1023 * 5;
        char f2[10];
        sprintf(f2, "%.2f", n);
        UART_Write_Text(f2);
//        __delay_ms(100);
    }
    return;
}
void main(void) 
{
    
    SYSTEM_Initialize() ;
    
    while(1) {
        strcpy(str, GetString());
        UART_Write_Text(str);
        ClearBuffer();
    }
    return;
}

void __interrupt(high_priority) Hi_ISR(void)
{

}